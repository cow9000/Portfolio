<?php
	include "scripts/nav.php";
	$_SESSION["username"] = "cow9000";
	include "pages/login.php";
?>