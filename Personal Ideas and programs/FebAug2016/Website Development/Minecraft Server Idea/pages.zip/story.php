<?php
	include "scripts/nav.php";
	
	
	//In here
	
	
	include "pages/storyline.php";
?>