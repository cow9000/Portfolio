<?php
	$conn = mysqli_connect("localhost","root","thechickenninja","server");
?>