<?php
	if(isset($_POST["pass"])){
		if($_POST["pass"] == "out"){
			echo "AJV38329jvia81uv8ioALgia39";
		}
		
		
		
	}else{
		echo "Unauthorized access, randomizing password.";
	}
?>